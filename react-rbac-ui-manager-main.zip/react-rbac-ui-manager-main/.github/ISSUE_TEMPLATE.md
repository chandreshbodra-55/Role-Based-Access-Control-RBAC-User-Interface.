Context
[provide more detailed introduction to the issue itself and why it is relevant]

Steps to reproduce
[ordered list the process to finding and recreating the issue]

Expected result
[describe what you would expect to have resulted from this process]

Current result
[describe what you you currently experience from this process, and thereby explain the bug]

Possible Fix
